import json
import os
from typing import Any

from .utils.oi_dir import oi_dir


_DEFAULT_SETTINGS_KEYS: dict[str, type] = {
    "model": str,
    "temperature": float,
    "context_window": int,
    "max_tokens": int,
    "auto_run": bool,
    "safe_mode": str,
}


def _settings_path() -> str:
    return os.path.join(oi_dir, "settings.json")


def load_settings() -> dict[str, Any]:
    path = _settings_path()
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except FileNotFoundError:
        return {}
    except Exception:
        return {}


def save_settings(settings: dict[str, Any]) -> None:
    os.makedirs(oi_dir, exist_ok=True)
    path = _settings_path()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2, ensure_ascii=False)


def _flag_was_provided(flag_name: str, nickname: str | None) -> bool:
    if f"--{flag_name}" in os.sys.argv:
        return True
    if nickname and f"-{nickname}" in os.sys.argv:
        return True
    return False


def apply_settings(interpreter, arguments: list[dict[str, Any]]) -> None:
    settings = load_settings()
    if not settings:
        return

    for arg in arguments:
        name = arg.get("name")
        if not name:
            continue
        if name not in settings:
            continue

        attr = arg.get("attribute")
        if not attr:
            continue

        if _flag_was_provided(name, arg.get("nickname")):
            continue

        value = settings.get(name)
        if value is None:
            continue

        setattr(attr["object"], attr["attr_name"], value)


def run_settings_wizard(interpreter) -> None:
    current = load_settings()

    next_settings: dict[str, Any] = {}
    for k, t in _DEFAULT_SETTINGS_KEYS.items():
        if k in current:
            next_settings[k] = current[k]
        else:
            if k == "model":
                next_settings[k] = getattr(interpreter.llm, "model", None)
            elif k == "temperature":
                next_settings[k] = getattr(interpreter.llm, "temperature", None)
            elif k == "context_window":
                next_settings[k] = getattr(interpreter.llm, "context_window", None)
            elif k == "max_tokens":
                next_settings[k] = getattr(interpreter.llm, "max_tokens", None)
            elif k == "auto_run":
                next_settings[k] = getattr(interpreter, "auto_run", None)
            elif k == "safe_mode":
                next_settings[k] = getattr(interpreter, "safe_mode", None)

    print(f"Settings file: {_settings_path()}")

    for key, expected_type in _DEFAULT_SETTINGS_KEYS.items():
        existing = next_settings.get(key)
        prompt = f"{key} [{existing}]: "
        raw = input(prompt)
        raw = raw.strip()

        if raw == "":
            continue
        if raw.lower() in {"none", "null", "clear"}:
            next_settings.pop(key, None)
            continue

        try:
            if expected_type is bool:
                if raw.lower() in {"1", "true", "t", "y", "yes", "on"}:
                    next_settings[key] = True
                elif raw.lower() in {"0", "false", "f", "n", "no", "off"}:
                    next_settings[key] = False
                else:
                    raise ValueError()
            elif expected_type is int:
                next_settings[key] = int(raw)
            elif expected_type is float:
                next_settings[key] = float(raw)
            else:
                next_settings[key] = raw
        except Exception:
            print(f"Invalid value for {key}. Keeping existing.")

    save_settings(next_settings)
    print("Saved.")
