from interpreter.terminal_interface.start_terminal_interface import main


if __name__ == "__main__":
    main()
